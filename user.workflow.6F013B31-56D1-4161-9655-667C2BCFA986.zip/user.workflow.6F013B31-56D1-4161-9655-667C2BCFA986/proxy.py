#!/usr/bin/python
# encoding: utf-8

import os, subprocess
from lib.workflow import Workflow
from lib.workflow.background import run_in_background
from lib.atools import Tools, AnkiFx

__usage__ = """
proxy.py <action> [options] [<name>|<did>] [<data>]

Usage:
    proxy.py apath
    proxy.py deck new <name>
    proxy.py card [new]

Arguments:
    <name>     Deck name
    <did>      Deck ID

Options:
    -h, --help      Show this help text

"""

DELIMITER = '‣'


ALFRED_SCRIPT = 'tell application "Alfred 2" to search "{}"'

def _applescriptify(text):
    """Replace double quotes in text"""
    return text.replace('"', '" + quote + "')


def run_alfred(query):
    """Run Alfred with ``query`` via AppleScript"""
    script = ALFRED_SCRIPT.format(_applescriptify(query))
    log.debug('calling Alfred with : {!r}'.format(script))
    return subprocess.call(['osascript', '-e', script])
    


def main(wf):
    from docopt import docopt
    args = docopt(__usage__, argv=wf.args)
    
    log.debug('PROXY wf.args : {!r}'.format(wf.args))
    log.debug('PROXY args : {!r}'.format(args))


    if args.get('deck') and args.get('new'):
        afx.create_deck(args['<name>'])
        print('Created {}'.format(args['<name>']))
        cmd = ['/usr/bin/python', wf.workflowfile('background.py'), 'decks']
        run_in_background('decks', cmd)

    if args.get('apath'):
        run_alfred(':apath {}'.format(DELIMITER))


    if args.get('card'):
        
        if not args.get('new'):
            cmd = """osascript -e 'tell application "Alfred 2" to run trigger "add_card" in workflow "net.drlulz.alfred-anki" with argument "{}"'""".format('//')
            os.system(cmd)
        
        if args.get('new'):        
            did = wf.cached_data('did', max_age=0)
            data = wf.cached_data('user_sides', max_age=0) #[u'Front', u'Back']
            afx.create_card(did, data)
            print('Created Card')
            cmd = ['/usr/bin/python', wf.workflowfile('background.py'), 'cards']
            run_in_background('cards', cmd)


if __name__ == '__main__':
    wf = Workflow(libraries=[os.path.join(os.path.dirname(__file__), 'lib')])
    log = wf.logger
    apath = wf.settings.get('anki_path', None)
    if apath:
        at = Tools(apath)
        afx = AnkiFx(apath)
    wf.run(main)