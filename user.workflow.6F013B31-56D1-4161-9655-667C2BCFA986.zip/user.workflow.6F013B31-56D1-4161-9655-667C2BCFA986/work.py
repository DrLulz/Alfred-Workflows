#!/usr/bin/python
# encoding: utf-8

## Structure from FuzzyFolders wf
#from __future__ import unicode_literals, print_function

import os, sys, re, subprocess
from lib.workflow import (Workflow, ICON_NOTE, ICON_WARNING,
                      ICON_INFO, ICON_SETTINGS, ICON_ERROR, ICON_SYNC)
from lib.workflow.background import run_in_background, is_running
from anki import Collection as aopen

__version__ = '1.0'

# [] optional
# () required
# | mutually exclusive

__usage__ = """
anki.py <action> [<dir>] [<query>]

Usage:
    anki.py set [<query>]
    anki.py list <query>
    anki.py decks
    anki.py apath <dir>
    anki.py create <query>

Arguments:
    <query>     Search query
    <apath>     Directory path

Options:
    -h, --help      Show this help text

This script is meant to be called from Alfred.

"""

log = None
DELIMITER = '‣'
ICON = 'icon.png'

ALFRED_SCRIPT = 'tell application "Alfred 2" to search "{}"'

def _applescriptify(text):
    """Replace double quotes in text"""
    return text.replace('"', '" + quote + "')


def run_alfred(query):
    """Run Alfred with ``query`` via AppleScript"""
    script = ALFRED_SCRIPT.format(_applescriptify(query))
    log.debug('calling Alfred with : {!r}'.format(script))
    return subprocess.call(['osascript', '-e', script])


def get_col():
    import glob

    default_locations = [
                         os.environ['HOME']+'/Anki/User 1/collection.anki2',
                         os.environ['HOME']+'/.anki/User 1/collection.anki2',
                         'collection.anki2'
                        ]

    for location in default_locations:
        if os.path.exists(location):
            return location

    home_path = os.path.expanduser('~')
    pattern = (home_path + '/**' + '/Anki' + '/*' + '/collection.anki2')
    col_path = glob.glob(pattern)
    
    if col_path:
        return col_path[0]
    else:
        return None
        

def db_decks(apath):
    from atools import Tools
    
    at = Tools(apath)
    results =[]

    decks = at.all_decks()
    
    for d in decks:
        deck = {'id': None, 'title': None, 'cards': None, 'new': None, 'review': None}
        
        deck['id']    = str(d['id'])
        deck['title'] = d['name']
        deck['cards'] = str(at.cnt_cards(d['id'], d['name']))
        
        stats = at.deck_stats(deck['id'], deck['title'])
        n, r, l = stats['new'], stats['review'], stats['learning']
        deck['new'] = n
        deck['review'] = r+l
            
        results.append(deck)
        
    return results



class Anki_WF(object):

    def __init__(self, wf):
        self.wf = wf
        self.query = None
        self.apath = self.wf.settings.get('anki_path', None)
        if self.apath:
            self.col = aopen(self.apath)
            self.dm = self.col.decks
        
        
    def run(self, args):

        self.args = args

        # ------------------------------------------------------------------
        # Check if Anki collection path is set
         
        if not self.apath and not self.args.get('apath'):
            self.apath = get_col()
            if self.apath is None:
                self.wf.add_item(
                    title    = "Run ':apath', or press return to set the collection path",
                    subtitle = "",
                    arg      = 'apath',
                    valid    = True,
                    icon     = ICON_WARNING)
                self.wf.send_feedback()
            elif self.apath:
                self.wf.settings['anki_path'] = self.apath
            return


        self.query = args['<query>']
        self.path  = args['<dir>']
        log.debug('query : {!r} path : {!r}'.format(self.query, self.path))

        actions = ('list', 'set', 'decks', 'apath', 'create')

        for action in actions:
            if args.get(action):
                methname = 'do_{}'.format(action.replace('-', '_'))
                meth = getattr(self, methname, None)
                if meth:
                    return meth()
                else:
                    break

        raise ValueError('Unknown action : {}'.format(action))


    ####################################################################
    # Deck Search
    ####################################################################

    def do_list(self):
        
        # ------------------------------------------------------------------
        # Parse query        

        m = re.match(u'([^‣]+)(‣)?(.+)?', self.query)
        #m = re.match(u'([^‣]+)(‣)?([^‣]+)?(‣)?([^‣]+)?', self.query)

        if not m:
            self.wf.add_item('Create Deck?',
                        'or try a different query',
                        icon=ICON_WARNING)
            self.wf.send_feedback()
            return 0

        dq, delim, cq = m.groups()

        log.debug('\n\nDeck Query: {!r}\nDelim: {!r}\nCard Query: {!r}\n'.format(dq, delim, cq))


        # ------------------------------------------------------------------
        # Start searching for available decks
        
        if not delim:
            
            def key_for_deck(deck):
                return '{} {}'.format(deck['title'], deck['id'])

            decks = wf.cached_data('decks', None, max_age=0) #86400
            
            if not wf.cached_data_fresh('decks', max_age=86400):
                     cmd = ['/usr/bin/python', wf.workflowfile('background.py'), 'decks']
                     log.debug('CMD: {}'.format(cmd))
                     run_in_background('decks', cmd)
                     
            if is_running('decks'):
                     self.wf.add_item('Updating deck info', valid=False, icon=ICON_SYNC)
            
            '''
            if not dq:
                self.wf.add_item(
                    title    = 'Start typing to search for decks...',
                    subtitle = 'Create card in {}'.format(dq),
                    arg      = did,
                    valid    = False,
                    icon     = ICON)
        
                self.wf.send_feedback()
            '''
            
            if self.query and decks:
                decks = wf.filter(dq, decks, key_for_deck, min_score=64)
        
            if not decks:
                #self.wf.add_item('No decks with that name. Create?', icon=ICON_WARNING)
                new_deck = 'deck new "{}"'.format(dq)
                log.debug('CREATE NEW DECK: {}'.format(new_deck))
                
                self.wf.add_item(
                    title    = 'Deck not found. Create "{}"?'.format(dq),
                    subtitle = 'Press return to create new deck.',
                    arg      = new_deck,
                    valid    = True,
                    icon     = ICON_WARNING)
                
                self.wf.send_feedback()
                #create_deck(apath, query)
                return 0
            
            # set uid
            for deck in decks:
                self.wf.add_item(
                    title    = deck['title'],
                    subtitle = 'Cards:{}   New:{}   Review:{}'.format(deck['cards'], deck['new'], deck['review']),
                    #arg      = 'did {}'.format(deck['id']),
                    autocomplete=wf.decode('{} ‣'.format(deck['title'])),
                    #uid      = wf.decode(deck['id']),
                    #valid    = False,
                    icon     = ICON)

            self.wf.send_feedback()
            return 0

        
        
        # ------------------------------------------------------------------
        # Get did from selected deck name
        
        def did_wrapper():
            did = self.dm.byName(dq.strip())
            return did['id']
        
        did = wf.cached_data('did', did_wrapper, max_age=1)
        did = str(did)
        log.debug('\n\nDECK ID: {}  DECK NAME: {}\n'.format(did, dq.strip()))

        
        # ------------------------------------------------------------------
        # get cards for did

        cards = wf.cached_data(did, None, max_age=0) #86400
    
        if not wf.cached_data_fresh(did, max_age=86400):
                 cmd = ['/usr/bin/python', wf.workflowfile('background.py'), 'cards']
                 log.debug('CMD: {}'.format(cmd))
                 run_in_background('cards', cmd)
        
        
        if is_running('cards'):
            self.wf.add_item('Updating cards... wait one...', valid=False, icon=ICON_SYNC)         

                 
        if not cq:
            self.wf.add_item(
                title    = 'Start typing to search for cards...',
                subtitle = 'Create card in {}'.format(dq),
                arg      = did,
                valid    = False,
                icon     = ICON)
        
            self.wf.send_feedback()
        
                
        
                 
        
                                  
        
        if cq:
        
            def key_for_card(card):
                log.debug('\n\nKEY FOR CARD:\nFLDS:{!r}\nTAGS: {!r}\n'.format(card['flds'], card['tags'].strip()))
                return '{} {}'.format(card['flds'], card['tags'].strip())
        
        
            if self.query and cards:
                cards = wf.filter(cq, cards, key_for_card, min_score=64)
            
            self.wf.add_item(
                title    = 'New Card',
                subtitle = 'Create card in {}'.format(dq),
                arg      = 'card',
                valid    = True,
                icon     = ICON)
                
                
            if not cards:
                self.wf.add_item(
                    title    = "Can not find '{}' in deck '{}'".format(cq, dq),
                    subtitle = "",
                    valid    = False,
                    icon     = ICON)

                
                    
                #self.wf.send_feedback()
                
            if cards:
                for card in cards:
                    if card['img'] is None:
                        card['img'] = ICON
                        
                    self.wf.add_item(
                        title    = (card['flds']).encode('utf-8'),
                        subtitle = card['tags'],
                        arg      = str(card['nid']),
                        #uid      = wf.decode(card['nid']),
                        valid    = True,
                        icon     = card['img'])

            self.wf.send_feedback()
            return 0
        
        
        
    ####################################################################
    # Settings
    ####################################################################
    
    # ------------------------------------------------------------------
    # create menu for settings

    def do_set(self):
        
        if 'apath' in self.query:
            run_alfred(':apath {}'.format(DELIMITER))
            
        if 'update' in self.query:
            def wrapper():
                return db_decks(self.apath)
            decks = wf.cached_data('decks', wrapper, max_age=1)
            print('Decks Updated')
            log.debug('UPDATE: {}'.format(decks))
            
            
        
        apath = {'title': 'Set anki collection path',
                 'subtitle': 'Example: /Users/.../Documents/Anki/.../collection.anki2',
                 'arg': 'apath',
                 'uid': u'5c38d8fff8d80dab02f70318bfec8d',
                 'valid': True,
                 'icon': ICON_SETTINGS}

        update = {'title': 'Update collection',
                 'subtitle': 'Refresh cards in decks',
                 'arg': 'update',
                 'uid': u'109818cfaccb5d1bb41df56c81995e',
                 'valid': True,
                 'icon': ICON_SETTINGS}
                 
        settings = [apath, update]
        
        log.debug(settings)
        
        for setting in settings:
            self.wf.add_item(
                title    = setting['title'],
                subtitle = setting['subtitle'],
                arg      = setting['arg'],
                uid      = setting['uid'],
                valid    = setting['valid'],
                icon     = setting['icon'])
        self.wf.send_feedback()
        return 0
        
    # ------------------------------------------------------------------
    # set path to anki collection from user input (get_col() failed)
    
    def do_apath(self):
        apath = self.path
        m = re.match(u'(.+\/Anki\/.+\/)', apath)
        
        if not apath.endswith('.anki2'):

            if not 'Anki' in apath:
                self.wf.add_item(
                    title    = "Keep typing...",
                    subtitle = "",
                    valid    = False,
                    icon     = ICON_NOTE)
                self.wf.send_feedback()
                
            if m:
                self.wf.add_item(
                    title    = "The path must end with collection.anki2",
                    subtitle = "",
                    valid    = False,
                    icon     = ICON_WARNING)
                self.wf.send_feedback()
            
            if 'Anki' in apath:
                self.wf.add_item(
                    title    = "Now your anki user name (Default is User 1)...",
                    subtitle = "",
                    valid    = False,
                    icon     = ICON_NOTE)
                self.wf.send_feedback()
        
        if apath.endswith('.anki2'):
     
            if not os.path.exists(apath):
                self.wf.add_item(
                    title    = "Aww snap! The path entered doesn't exist.",
                    subtitle = "",
                    valid    = False,
                    icon     = ICON_ERROR)
                self.wf.send_feedback()
                
            else:
                log.debug('apath: {!r}'.format(apath))
                self.wf.add_item(
                    title    = "That looks good!",
                    subtitle = apath,
                    arg      = apath,
                    valid    = True,
                    icon     = ICON_INFO)
                self.wf.send_feedback()
                return 0

        
        
    ####################################################################
    # Creation
    ####################################################################
    
    def do_create(self):
        
        log.debug('HERE YOU ARE')
        #new, title = self.query.split('_')
        
        #if 'deck' in new:
        #    from atools import AnkiFx
        #    afx = AnkiFx(self.apath)
        #    afx.create_deck(title)
    

def main(wf):
    from docopt import docopt
    args = docopt(__usage__, argv=wf.args, version=__version__)
    
    log.debug('wf.args : {!r}'.format(wf.args))
    log.debug('args : {!r}'.format(args))
    
    awf = Anki_WF(wf)
    return awf.run(args)


if __name__ == '__main__':
    wf = Workflow(libraries=[os.path.join(os.path.dirname(__file__), 'lib')])
    log = wf.logger
    sys.exit(wf.run(main))