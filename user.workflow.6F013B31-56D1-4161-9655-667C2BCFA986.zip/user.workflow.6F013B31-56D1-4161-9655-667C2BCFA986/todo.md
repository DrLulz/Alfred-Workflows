# To Do

1. Anki Sync
2. Import csv
3. Search
4. account for sub decks in path Main::Sub::Sub-Sub when counting


5. sort decks by new, review, learning

6. open anki to specific deck

7. choose model (note type) when adding card

make deck, make child of a deck
rename decks

show total new, review


drill down: deck to card


fliter by times missed