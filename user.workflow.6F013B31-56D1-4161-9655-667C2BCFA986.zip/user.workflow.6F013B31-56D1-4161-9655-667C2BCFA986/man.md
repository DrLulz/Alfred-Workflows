# Cache

### retrieve data only if in cache

 data = wf.cached_data('stuff', None, max_age=600)
 data = wf.cached_data('stuff', max_age=600)
