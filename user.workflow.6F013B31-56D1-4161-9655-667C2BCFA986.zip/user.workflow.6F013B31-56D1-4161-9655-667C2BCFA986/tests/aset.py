# encoding: utf-8

## Structure from FuzzyFolders wf

import os, sys, subprocess
from workflow import (Workflow, ICON_NOTE, ICON_WARNING,
                      ICON_INFO, ICON_SETTINGS, ICON_ERROR)

__version__ = '1.0'

__usage__ = """
aset.py <action> [<dir>] [<query>]

Usage:
    aset.py apath <dir>

Arguments:
    <query>     Search query
    <dir>       Directory path

Options:
    -h, --help      Show this help text

This script is meant to be called from Alfred.

"""

log = None
DELIMITER = '▸'


ALFRED_SCRIPT = 'tell application "Alfred 2" to search "{}"'

def _applescriptify(text):
    """Replace double quotes in text"""
    return text.replace('"', '" + quote + "')


def run_alfred(query):
    """Run Alfred with ``query`` via AppleScript"""
    script = ALFRED_SCRIPT.format(_applescriptify(query))
    log.debug('calling Alfred with : {!r}'.format(script))
    return subprocess.call(['osascript', '-e', script])



class AnkiSet(object):

    def __init__(self, wf):
        self.wf = wf
        self.query = None
        #self.apath = self.wf.settings.get('anki_path', None)
        
        
    def run(self, args):

        self.args = args
        
        #self.query = args['<query>']

        #log.debug('query : {!r}'.format(self.query))

        actions = ('apath', 'blah')

        for action in actions:
            if args.get(action):
                methname = 'do_{}'.format(action.replace('-', '_'))
                meth = getattr(self, methname, None)
                if meth:
                    return meth()
                else:
                    break

        raise ValueError('Unknown action : {}'.format(action))

        
    def do_apath(self):
        
        apath = self.args['<dir>']
        
        if not apath.endswith('collection.anki2'):
            self.wf.add_item(
                title    = "The path you entered isn't valid",
                subtitle = "Anki collections end with .anki2",
                valid    = False,
                icon     = ICON_WARNING)
            self.wf.send_feedback()
            return 0

        
        if not os.path.exists(apath):
            self.wf.add_item(
                title    = "Aww snap. The path doesn't exist.",
                subtitle = "The path entered doesn't exist.",
                valid    = False,
                icon     = ICON_WARNING)
            self.wf.send_feedback()
            return 0

        log.debug('apath: {}'.format(apath))
        self.wf.settings['anki_path'] = apath
        self.wf.send_feedback()
                

def main(wf):
    from docopt import docopt
    args = docopt(__usage__, argv=wf.args, version=__version__)
    
    log.debug('wf.args : {!r}'.format(wf.args))
    log.debug('args : {!r}'.format(args))
    
    awf = Anki_WF(wf)
    return awf.run(args)


if __name__ == '__main__':
    wf = Workflow(libraries=[os.path.join(os.path.dirname(__file__), 'lib')])
    log = wf.logger
    sys.exit(wf.run(main))