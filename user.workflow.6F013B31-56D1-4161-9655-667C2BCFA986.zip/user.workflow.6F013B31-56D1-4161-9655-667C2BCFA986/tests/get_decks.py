#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os, sys, re, argparse
from atools import Tools
from workflow import Workflow, ICON_WARNING

log = None
    
def get_col():
    import glob

    default_locations = [
                         os.environ['HOME']+'/Anki/User 1/collection.anki2',
                         os.environ['HOME']+'/.anki/User 1/collection.anki2',
                         'collection.anki2'
                        ]

    for location in default_locations:
        if os.path.exists(location):
            return location

    home_path = os.path.expanduser('~')
    pattern = (home_path + '/**' + '/Anki' + '/*' + '/collection.anki2')
    col_path = glob.glob(pattern)
    
    if col_path:
        return col_path[0]
    else:
        return None

    
def create_deck(apath, title):
    at = Tools(apath)
    at.create_deck(title)
    

def db_decks(apath):
 
    at = Tools(apath)
    results =[]

    decks = at.all_decks()
    
    for d in decks:
        deck = {'id': None, 'title': None, 'cards': None, 'new': None, 'review': None}
        
        deck['id']    = str(d['id'])
        deck['title'] = d['name']
        deck['cards'] = str(at.cnt_cards(d['id'], d['name']))
        
        stats = at.deck_stats(deck['id'], deck['title'])
        n, r, l = stats['new'], stats['review'], stats['learning']
        deck['new'] = n
        deck['review'] = r+l
        
        #if deck['cards'] is '0':
        #    continue
            
        log.debug(deck)
        results.append(deck)
        
    return results
    

def key_for_deck(deck):
    return '{} {}'.format(deck['title'], deck['id'])


def main(wf):
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--setpath', dest='apath', nargs='?', default=None)
    parser.add_argument('query', nargs='?', default=None)
    args = parser.parse_args(wf.args)
    
    if args.apath:
        wf.settings['anki_path'] = args.apath
        return 0
        
    apath = wf.settings.get('anki_path', None)
    if not apath:
        apath = get_col()
        if apath is None:
            wf.add_item("Cant find Anki's collection path.",
                'Please use :apath to set your collection path.',
                valid=False,
                icon=ICON_WARNING)
            wf.send_feedback()
            return 0
        elif apath:
            wf.settings['anki_path'] = apath

    
    query = args.query
    
    
    def wrapper():
        return db_decks(apath)
             

    decks = wf.cached_data('decks', wrapper, max_age=1) #86400


    if query:
        decks = wf.filter(query, decks, key_for_deck, min_score=20)


    if not decks:
        wf.add_item('No decks with that name. Create?', icon=ICON_WARNING)
        wf.send_feedback()
        create_deck(apath, query)
        return 0

    # set uid
    for deck in decks:
        wf.add_item(
            title    = deck['title'],
            subtitle = 'Cards:{}   New:{}   Review:{}'.format(deck['cards'], deck['new'], deck['review']),
            arg      = '{} {}'.format(deck['id'], deck['title']),
            valid    = True,
            icon     = 'icon.png')

    wf.send_feedback()
    return 0
    
    
    
if __name__ == '__main__':
    wf = Workflow()
    log = wf.logger
    sys.exit(wf.run(main))