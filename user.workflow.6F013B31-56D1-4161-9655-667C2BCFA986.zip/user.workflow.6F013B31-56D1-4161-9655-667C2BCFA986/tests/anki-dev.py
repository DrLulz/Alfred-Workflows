#!/usr/local/bin/python
# -*- coding: utf-8 -*-


# [Run from subdirectory]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)
#sys.path.append("/usr/share/anki")


# [IMPORT]
import re, glob
#import anki
import sqlite3
import json

from anki import storage, stats
from BeautifulSoup import BeautifulSoup, Comment, NavigableString





# [COLLECTION]

# TO DO: after finding save to memory

#COLLECTION_PATH = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'

def get_col():
    default_locations = [
                         os.environ['HOME']+'/Anki/User 1/collection.anki2',
                         os.environ['HOME']+'/.anki/User 1/collection.anki2',
                         'collection.anki2'
                        ]
    for location in default_locations:
        if os.path.exists(location):
            return location
        else:
            home_path = os.path.expanduser('~')
            pattern = (home_path + '/**' + '/Anki' + '/*' + '/collection.anki2')
            for path in glob.glob(pattern):
                return path
    return None
    

col = storage.Collection(get_col())
#print col


'''
# [Other Directories]
def addon_dir(path):
    return (os.path.normpath(os.path.join(path, "../..")) + '/addons')

print col.media.dir()
#col.media.addFile(file)
print addon_dir(get_col())
'''


# [HANDLE ANKI QUERIES RETURNED VIA HTML]

def remove(soup, tagname):
    for tag in soup.findAll(tagname):
        contents = tag.contents
        parent = tag.parent
        tag.extract()
        

def strip_tags(soup, invalid_tags):
    for tag in soup.findAll(True):
        if tag.name in invalid_tags:
            s = ""
            for c in tag.contents:
                if not isinstance(c, NavigableString):
                    c = strip_tags(unicode(c), invalid_tags)
                s += unicode(c)
            tag.replaceWith(s)
    return soup
    

def parse_response(response):

    soup = BeautifulSoup(response)    
    comments = soup.findAll(text=lambda text:isinstance(text, Comment))
    [comment.extract() for comment in comments]
    
    strip_tags(soup, ['b'])
    #strip_tags(soup, ['td'])

    remove(soup, ['h1'])
    new_soup = unicode(soup)
    return re.sub('<br />','\n', new_soup)
    

# [STATS]

col_stats = stats.CollectionStats(col)
stats_today = col_stats.todayStats()

due = col_stats.cardGraph()
#all_stats = col_stats.report() #maybe for a popup (returns a html page)

#print parse_response(due)

#cards = col_stats._cards()
#print cards


#print all_stats


### [All Decks]
decks = col.decks.all() # all info
decks_name = col.decks.allNames() # all names
decks_did = col.decks.allIds() # all ids
decks_count = col.decks.count() # count
decks_options = col.decks.allConf() # options for deck (random, lapse times, etc)

### [Deck]
DECK_NAME = ''
aparent = 'Yousmle.com'
achild = 'Bacterial Viral Characteristics'
anothername = 'MEDICINE::Pharm - Drug of Addiction'
adid = '1422287940728'
DrLulz = '1426073216269'
DrLulzOMM_SNS_Pre = '1419424106618'
DrLulzOMM = '1427368232319'

#DECK_NAME = col.decks.name(DrLulz)
#DECK_NAME_c = col.decks.name(DrLulzOMM)

# deck path
deck_name_base = col.decks._basename(DECK_NAME) # return base name
deck_name_path = col.decks._path(DECK_NAME) # returns full name as list

# return all info by specifier
deck_by_did = col.decks.get(DrLulz, default=False)
deck_by_name = col.decks.byName(DECK_NAME)



deck_id = col.decks.id(anothername) # return did from name
#DECK_NAME = col.decks.name(DrLulz) # return name from did
#print deck_id


bool_parent = col.decks._isParent(DECK_NAME, DECK_NAME) #(parent, child)
bool_ancestor = col.decks._isAncestor(aparent, achild)
bool_ = col.decks._ensureParents(DECK_NAME) # not sure what this does
deck_options = col.decks.confForDid(adid) # random, lapse times, etc

#print deck_by_did
DECK_NAME = 'Yousmle.com::Bacterial Viral Characteristics' #124
check_parents = col.decks._ensureParents(DECK_NAME)

print check_parents




collection_creation_date = None
def get_collection_creation_date(conn):
    global collection_creation_date
    if not collection_creation_date:
        row = conn.execute('select crt from col where id=1').fetchone()
        if not row:
            raise Error("Couldn't read collection.")
        else:
            try:
                collection_creation_date = datetime.datetime.fromtimestamp(row['crt']).date()
            except ValueError:
                raise Error("Couldn't understand collection's creation date: {}".format(row['crt']))
    return collection_creation_date


def query_db(path):
    
    #DECK_NAME = 'Yousmle.com::Bacterial Viral Characteristics'
    DECK_NAME = 'MEDICINE::Pharm - Drug of Addiction'
    db = sqlite3.connect(path)
    
    #csr = db.cursor()
    #csr.row_factory = sqlite3.Row
    #csr.execute('SELECT decks FROM col')
    
    
    d_db = db.execute("SELECT decks FROM col")
    """    
    for row in db.execute("SELECT notes.id "
                     "FROM notes, cards "
                     "WHERE notes.id=cards.nid "
                     "AND cards.did like ?", ('%'+DrLulzOMM+'%',)):

                     """
#    row = db.execute("SELECT COUNT(*) "
#                         "FROM cards, notes "
#                         "WHERE notes.id=cards.nid AND cards.did like ?", ('%'+DrLulzOMM_SNS_Pre+'%',))

    #csr.execute("SELECT decks "
#                         "FROM col "
#                         "WHERE decks like ?", ('%'+DrLulzOMM_SNS_Pre+'%',))  
                         
    #selection = json.dumps(dict(result=[dict(r) for r in csr.fetchall()]))
    
    #print selection  
    #mod = row.fetchone()
    #_count = mod[0]
    #print _count
#    mod = json.loads(row.fetchone()[0])
#    for r in mod.items():
#        print r['id']
                     
#                     conn.execute("select * from notes where tags like ?",('%'+tag+'%',))
    #models = json.loads(row.fetchone()[0])
#    models = row.fetchone()
#    models_count = models[0]
#    print models

    
    decks = json.loads(d_db.fetchone()[0])
    
    for id, deck in decks.items():
        #print deck
        if deck['name'] == DECK_NAME:
            selected_deck = deck
            selected_deck['id'] = id
            break
    else:
        print("Unable to find the %r deck :(" % DECK_NAME)
        
    
    cards = db.execute("SELECT cards.id, nid, did, flds, sfld "
                         "FROM cards "
                         "JOIN notes ON notes.id = cards.nid "
                         "WHERE cards.did = ?", (DrLulzOMM_SNS_Pre,) )
                         
    
    
    c_cnt_by_did = db.execute("SELECT COUNT(*) "
                                    "FROM cards "
                                    "WHERE cards.did = ?", (DrLulz,) )
                    
    c_cnt_result = c_cnt_by_did.fetchone()
    card_count = c_cnt_result[0]
    
    #print len(cards)
    fdsfd = []
    for card in cards:
        id, note_id, deck_id, front, back = card
        fdsfd.append(card)
        #print card
    #print len(fdsfd)

        
def anki_db(anki_col_path, handler=None):
    
    if handler is None:
        handler = {}
    
            
def conn_db(anki_col_path, **handler):
    
    conn = sqlite3.connect(anki_col_path)


    
    
query_db(get_col())

#print decks