#!/usr/bin/env python
# -*- coding: utf-8 -*-


# [Run from subdirectory]
import os, sys
#abspath = os.path.abspath(__file__)
#dname = os.path.dirname(abspath) + '/main'
#sys.path.append(dname)



# [IMPORT]
import re
import sqlite3
import json
#from anki import storage, stats
#from BeautifulSoup import BeautifulSoup, Comment, NavigableString
from workflow import Workflow, ICON_WARNING
#from __future__ import unicode_literals
#import xml.etree.ElementTree as etree
#import logging
import argparse



log = None
    
def get_col():
    import glob

    default_locations = [
                         os.environ['HOME']+'/Anki/User 1/collection.anki2',
                         os.environ['HOME']+'/.anki/User 1/collection.anki2',
                         'collection.anki2'
                        ]

    for location in default_locations:
        if os.path.exists(location):
            return location

    home_path = os.path.expanduser('~')
    pattern = (home_path + '/**' + '/Anki' + '/*' + '/collection.anki2')
    col_path = glob.glob(pattern)
    
    if col_path:
        return col_path[0]
    else:
        return None


    

def db_decks(apath):
 
    results =[]
    db = sqlite3.connect(apath)
    deck_db = db.execute("SELECT decks FROM col")

    decks = json.loads(deck_db.fetchone()[0])

    for d in decks.items():
#        deck = {'title': None, 'cards': None, 'id': None}
        deck = {'title': None, 'id': None}

        deck['title'] = d[1]['name']
        deck['id'] = d[0]
        
        #log.debug(deck)
        
        if deck['id'] is None:
            continue

        results.append(deck)
    
    return results
         

    
#    cards_did = db.execute("SELECT COUNT(*) "
#                                    "FROM cards "
#                                    "WHERE cards.did = ?", (selected_deck['id'],) )
                                    
#    card_rows = cards_did.fetchone()
#    return card_rows[0]
    
def key_for_deck(deck):
    return '{} {}'.format(deck['title'], deck['id'])


def main(wf):
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--setpath', dest='apath', nargs='?', default=None)
    parser.add_argument('query', nargs='?', default=None)
    args = parser.parse_args(wf.args)
    
    if args.apath:
        wf.settings['anki_path'] = args.apath
        return 0
        
    apath = wf.settings.get('anki_path', None)
    if not apath:
        apath = get_col()
        if apath is None:
            wf.add_item("Cant find Anki's collection path.",
                'Please use :apth to set your collection path.',
                valid=False,
                icon=ICON_WARNING)
            wf.send_feedback()
            return 0
        elif apath:
            wf.settings['anki_path'] = apath

    
    query = args.query
    
    
    def wrapper():
        return db_decks(apath)
             

    decks = wf.cached_data('decks', wrapper, max_age=600)


    if query:
        decks = wf.filter(query, decks, key_for_deck, min_score=20)


    if not decks:
        wf.add_item('No items', icon=ICON_WARNING)
        wf.send_feedback()
        return 0

    wf.add_item(
        title    = deck['title'],
        subtitle = deck['id'],
        arg      = deck['id'] + ' ' + deck['title'],
        valid    = True,
        icon     = 'icon.png')

    for deck in decks:
        wf.add_item(
            title    = deck['title'],
            subtitle = deck['id'],
            arg      = deck['id'] + ' ' + deck['title'],
            valid    = True,
            icon     = 'icon.png')

    wf.send_feedback()
    return 0
    
    
    
if __name__ == '__main__':
    wf = Workflow()
    log = wf.logger
    sys.exit(wf.run(main))