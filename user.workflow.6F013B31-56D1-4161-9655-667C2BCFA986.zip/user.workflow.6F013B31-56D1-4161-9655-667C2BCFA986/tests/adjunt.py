#!/usr/local/bin/python
# -*- coding: utf-8 -*-


# [Run from subdirectory]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)
#sys.path.append("/usr/share/anki")


# [IMPORT]
import re, glob
#import anki
import sqlite3
import json

from anki import storage, stats
from BeautifulSoup import BeautifulSoup, Comment, NavigableString



COLLECTION_PATH = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'

DECK_NAME = 'MEDICINE::Pharm - Drug of Addiction' #36
DID = '1427634157800'
NID = '1264521038872'

db = sqlite3.connect(COLLECTION_PATH)


def sync_info(db):
    sync = db.execute("SELECT ls FROM col")
    sync_time = sync.fetchone()[0]

    #import datetime    
    # strftime('%A, %b %d %I:%M:%S %p')



def deck_info_all(db):
    '''Returns a list of dicts with all deck info'''
    
    # name, extendRev, collapsed, browserCollapsed,
    # newToday, timeToday, extendNew, conf, revToday
    # lrnToday, id, mod

    results = []
    
    decks = db.execute("SELECT decks FROM col")                     
    decks = json.loads(decks.fetchone()[0])

    for id, deck in decks.items():
        results.append(deck)
#        print datetime.datetime.fromtimestamp(deck['mod']).strftime('%A, %b %d %I:%M%p %Y')

    return results


def deck_info(db, **kwargs):
    '''Returns deck info by -// name or did //-,
       if by name can be more than one deck
       to account for parent decks.'''
       
    options = {'did' : None, 'name' : None}
    options.update(kwargs)
    
    decks = db.execute("SELECT decks FROM col")
    decks = json.loads(decks.fetchone()[0])
    
    results = []
    
    for id, deck in decks.items():
        if options['did']:
            if id == options['did']:   
                return deck
        if options['name']:
            if deck['name'] == options['name']:
                results.append(deck)

    return results



def deck_config_all(db):
    '''These are the deck options'''
    # name replayq lapse rev timer dyn
    # maxTaken usn new mod id autoplay
    
    configs = db.execute("SELECT dconf FROM col")    
    configs = json.loads(configs.fetchone()[0])
    
    results = []
    
    for id, conf in configs.items():
        results.append(conf)
    
    return results




def model_info(db):
    '''A lot of info here'''
    raise Exception('are you sure?')    
    # name tags did usn req flds sortf
    # tmpls mod latexPost latexPre
    # type id css
    
    models = db.execute("SELECT models FROM col")    
    models = json.loads(models.fetchone()[0])
    
    results = []
    
    for id, model in models.items():
        results.append(model)
        
    return results




def card_info(db, **kwargs):

    # id nid did ord mod usn queue
    # due ivl factor reps lapses 
    # left odue odid flags data
    
    
    options = {'nid' : None, 'did' : None, 'count' : False}
    options.update(kwargs)
    
    
    
    # card count by deck id
    # card_info(db, did=DID, count=True)
    
    
    if options['did'] and options['count'] is True:
        
        cards_did = db.execute("SELECT COUNT(*) "
                                        "FROM cards "
                                        "WHERE cards.did = ?", (options['did'],) )
                    
        card_count = cards_did.fetchone()
        return card_count[0]
    
    
    
    # card_info(db, nid=NID)
    
    elif options['nid']:

        rows = db.execute("SELECT * FROM cards WHERE cards.nid = ?", (options['nid'],))
        
        colname = [ d[0] for d in rows.description ]
        for r in rows.fetchall():
            card = dict((colname[i], r[i]) for i in range(len(colname)))
            return card



    # card_info(db, did=DID)

    elif options['did']:

        results = []
        
        rows = db.execute("SELECT cards.id, nid, did, ord, cards.mod, cards.usn, queue, due, ivl, factor, reps, lapses, left, odue, odid, cards.flags, cards.data "
                             "FROM cards "
                             "JOIN notes ON notes.id = cards.nid "
                             "WHERE cards.did = ?", (options['did'],) )
        

        colname = [ d[0] for d in rows.description ]        
        for r in rows:
            card = dict((colname[i], r[i]) for i in range(len(colname)))
            results.append(card)
       
        return results



def card_spec(db, v, **kwargs):
        
    # card_spec(db, 'due', did='1419424106618')
    # card_spec(db, 'due', nid='1419441282918')
    # card_spec(db, 'queue', nid='1419441282918')
    # card_spec(db, 'due', cid='1419441341030')
    # card_spec(db, 'did', cid='1419441341030')

    results = []

    sel = {'v':('card_' + v)}

    options = {'cid' : None, 'nid' : None, 'did' : None}
    options.update(kwargs)
    
    if options['cid']:
        key, value = 'id', options['cid']
    elif options['nid']:
        key, value = 'nid', options['nid']
    elif options['did']:
        key, value = 'did', options['did']
    
    
    rows = db.execute("SELECT cards.id, cards.nid, cards.did, cards.ord, cards.mod, cards.usn, cards.queue, cards.due, cards.ivl, cards.factor, cards.reps, cards.lapses, cards.left, cards.odue, cards.odid, cards.flags, cards.data "
                         "FROM cards "
                         "JOIN notes ON notes.id = cards.nid "
                         "WHERE cards."+key+" = ?", (value,) )

    for card in rows:
        card_id, card_nid, card_did, card_ord, card_mod, card_usn, card_queue, card_due, card_ivl, card_factor, card_reps, card_lapses, card_left, card_odue, card_odid, card_flags, card_data = card
        results.append(vars()[sel['v']])
    
    return results



    
def note_info(db, **kwargs):
    # id guid mod usn tags flds sfld csum flags data mid
    # note_info(db, nid='1232312', count=True)

    
    options = {'nid' : None, 'count' : False}
    options.update(kwargs)
    

    if options['count'] is True:        
        notes = db.execute("SELECT count() FROM notes")
        total_notes = notes.fetchone()[0]
        return total_notes
        
                
    elif options['nid']:

        rows = db.execute("SELECT * FROM notes WHERE notes.id = ?", (options['nid'],))
        
        colname = [ d[0] for d in rows.description ]
        for r in rows.fetchall():
            return dict((colname[i], r[i]) for i in range(len(colname)))

    else:
        '''A lot of info (ALL NOTES)'''
        raise Exception('are you sure?')
        results = []
        rows = db.execute("SELECT * FROM notes")
        colname = [ d[0] for d in rows.description ]
    
        for r in rows.fetchall():
            note = dict((colname[i], r[i]) for i in range(len(colname)))
            results.append(note)
        
        return results



def note_spec(db, v, **kwargs):
    # id guid mod usn tags flds sfld csum flags data mid
    
    # note_spec(db, 'mid', nid=1264521038872)
    # note_spec(db, 'tags', nid=1264521038872)
    # note_spec(db, 'id', mid=1204533978) # all note ids with mid

    #guid: f#z!8<!TCo
    #id: 1264521038872
    results = []
    
    sel = {'v':('note_' + v)}

    options = {'nid' : None, 'tags' : None, 'mid' : None}
    options.update(kwargs)
    

    if options['nid']:
        key, value = 'id', options['nid']
    elif options['tags']:
        key, value = 'tags', options['tags']
    elif options['mid']:
        key, value = 'mid', options['mid']

    rows = db.execute("SELECT notes.id, notes.guid, notes.mod, notes.usn, notes.tags, notes.flds, notes.sfld, notes.csum, notes.flags, notes.data, notes.mid "
                         "FROM notes "
                         "WHERE notes."+key+" = ?", (value,) )

    for note in rows:
        note_id, note_guid, note_mod, note_usn, note_tags, note_flds, note_sfld, note_csum, note_flags, note_data, note_mid = note
        results.append(vars()[sel['v']])
    
    return results
        



### Example

def base_name(did):
    # get deck by did, filter dict by name
    deck_ = deck_info(db, did=did)
    # return base name of deck
    return deck_['name'].split('::')[0]


print base_name(DID)
#matches = match_deck(deck_name, all_decks)
#def match_deck(name, all_names):
def _match_(dk, dv, all_decks):
    '''match base name against all names
    return all children of base name'''
    results = []

    # name, extendRev, collapsed, browserCollapsed,
    # newToday, timeToday, extendNew, conf, revToday
    # lrnToday, id, mod    
    key = [dk]
    #key = ['name']
    
    for d in all_decks:
        d1 = {k: d[k] for k in (key)}
        d2 = {k:v for k, v in d1.items() if dv in str(v)}
        
        if len(d2.keys()):
            results.append(d2)

    return results



def sum_cards(matches):

    # retrieve deck ids, by name, that matched
    deck_ids = []
    for match in matches:
        match = match['name']
        #print deck_info(db, name=match)[0]['mod']
        ids = deck_info(db, name=match)[0]['id']
        deck_ids.append(ids)


    # get card count of each matched deck    
    sum_cards = []
    for ids in deck_ids:
        count = card_info(db, did=ids, count=True)
        sum_cards.append(count)

    # sum cards of each deck that matched
    return sum(sum_cards)
    


#db = sqlite3.connect(COLLECTION_PATH)
#db.row_factory = sqlite3.Row
#connection = sqlite3.connect(collection)
#connection.row_factory = sqlite3.Row


#base_name = base_name(DID)
#all_decks = deck_info_all(db)
#matches = _match_('name', base_name, all_decks)
#print sum_cards(matches)
#print deck_info_all(db)

db.close()