#!/usr/local/bin/python
# -*- coding: utf-8 -*-


# [Run from subdirectory]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)
#sys.path.append("/usr/share/anki")


# [IMPORT]
import re, glob
#import anki
import sqlite3
import json

from anki import storage, stats
from BeautifulSoup import BeautifulSoup, Comment, NavigableString



COLLECTION_PATH = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'

DECK_NAME = 'MEDICINE::Pharm - Drug of Addiction' #36
DID = '1427634157800'
NID = '1264521038872'



def deck_info_all(db):
    '''Returns a list of dicts with all deck info'''
    
    # name, extendRev, collapsed, browserCollapsed,
    # newToday, timeToday, extendNew, dbf, revToday
    # lrnToday, id, mod

    results = []
    
    decks = db.execute("SELECT decks FROM col")                     
    decks = json.loads(decks.fetchone()[0])

    for id, deck in decks.items():
        results.append(deck)
#        print datetime.datetime.fromtimestamp(deck['mod']).strftime('%A, %b %d %I:%M%p %Y')

    return results


def deck_info(db, **kwargs):
    '''Returns deck info by -// name or did //-,
       if by name can be more than one deck
       to account for parent decks.'''
       
    options = {'did' : None, 'name' : None}
    options.update(kwargs)
    
    decks = db.execute("SELECT decks FROM col")
    decks = json.loads(decks.fetchone()[0])
    
    results = []
    
    for id, deck in decks.items():
        if options['did']:
            if id == options['did']:   
                return deck
        if options['name']:
            if deck['name'] == options['name']:
                results.append(deck)

    return results



#db = sqlite3.dbnect(COLLECTION_PATH)
#db.row_factory = sqlite3.Row
def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


db = sqlite3.connect(COLLECTION_PATH)
db.row_factory = sqlite3.Row
#db.row_factory = dict_factory
cur = db.cursor()
cur.execute('SELECT decks FROM col')
print cur.fetchone()['decks']

#print deck_info_all(db)

db.close()
#db.close()