#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from workflow import Workflow, ICON_WARNING
from atools import AnkiFx


log = None

def main(wf):

    did = wf.cached_data('did', max_age=0)
    data = wf.cached_data('user_sides', max_age=0) #[u'Front', u'Back']
    afx.create_card(did, data)


if __name__ == '__main__':
    wf = Workflow()
    afx = AnkiFx(wf.settings.get('anki_path', None))
    log = wf.logger
    sys.exit(wf.run(main))