#!/usr/bin/env python

import os
from workflow import Workflow

wf = Workflow()

def get_did():
    arg = "{query}".split()
    return arg[0]
    
def get_title():
    arg = "{query}".split(' ', 1)
    return arg[1]

wf.cached_data('did', get_did, max_age=1)
wf.cached_data('deck_title', get_title, max_age=1)

cmd = """osascript -e 'tell application "Alfred 2" to run trigger "add_card" in workflow "net.drlulz.anki" with argument "%s"'""" % '//'

os.system(cmd)

#!/usr/local/bin/python
# -*- coding: utf-8 -*-

import re

#d = 'r\xe2\x96\xb8blah\xe2\x96\xb8wut'.decode('utf-8')
d = 'r\xe2\x96\xb8'.decode('utf-8')


#print d


m = re.match(u'([^▸]+)(▸)?(.+)?', d)
#m = re.match(u'([^▸]+)(▸)?([^▸]+)?(▸)?([^▸]+)?', d)

name, slash, query = m.groups()

print slash