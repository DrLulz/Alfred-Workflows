from lib.workflow import Workflow
from lib.atools import Tools


def db_decks(at):

    results =[]
    decks = at.all_decks()

    for d in decks:
        deck = {'id': None, 'title': None, 'cards': None, 'new': None, 'review': None}

        deck['id']    = str(d['id'])
        deck['title'] = d['name']
        deck['cards'] = str(at.cnt_cards(d['id'], d['name']))

        stats = at.deck_stats(deck['id'], deck['title'])
        n, r, l = stats['new'], stats['review'], stats['learning']
        deck['new'] = n
        deck['review'] = r+l

        results.append(deck)
    
    return results



def main(wf):


    
    def wrapper():
        return db_decks(at)

    decks = wf.cached_data('decks', wrapper, max_age=300)

    wf.logger.debug('{} anki decks cached'.format(len(decks)))



if __name__ == '__main__':
    wf = Workflow()
    at = Tools(wf.settings.get('anki_path', None))    
    wf.run(main)