s = 'ONE::TWO::THREE'
spl = s.split('::')
length = len(spl)
print length





# if length is 1 and count is zero
### search for ONE and sum decks
### if serach is zero = no cards

cnt = 0
#length = 1



# if length is 2 and count is zero
### search for ONE::TWO and sum decks
### if search is zero = no cards


if cnt == 0:
    
    
    if length == 1:
        return
    elif length == 2:
        return
    elif length == 3:
        return
    elif length == 4:
        return
    elif length == 5:
        return

# if length is 3 and count is zero
### search for ONE::TWO::THREE and sum decks
### if search is zero = no cards