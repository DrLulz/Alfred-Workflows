#!/usr/local/bin/python
# -*- coding: utf-8 -*-



#import os, sys
#abspath = os.path.abspath(__file__)
#dname = os.path.dirname(abspath)
#sys.path.append(dname)

#print dname
from atools import AnkiFx
#from anki import Collection as aopen


COLLECTION_PATH = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'

#DECK_NAME = 'MEDICINE::ACLS::ECG Rhythms'

#at = Tools(COLLECTION_PATH)


DECK_NAME = 'Yousmle.com'
#DECK_NAME = DECK_NAME.rsplit('::', 1)[0]
#DECK_NAME = 'MEDICINE'


DID = '1419273664195'
NID = '1429537251821'

#col = aopen(COLLECTION_PATH)

afx = AnkiFx(COLLECTION_PATH)

afx.create_deck('TEST')

#print afx.children(DID)

#dm = col.decks
#print dm.children(DID)

#print at.cnt_cards(DID, DECK_NAME)


#print at.all_decks()
#print at.deck_info(name=DECK_NAME)
#print at.note_info(nid=NID)
#{u'desc': u'', u'name': u'MEDICINE::ACLS', u'extendRev': 50, u'usn': -1, u'collapsed': False, u'newToday': [403, 0], u'lrnToday': [403, 0], u'dyn': 0, u'extendNew': 10, u'conf': 1, u'revToday': [403, 0], u'timeToday': [403, 0], u'id': 1428672590748, u'mod': 1429650919}


#print at.cnt_cards('1428672590748', DECK_NAME)


#print results
#print at.deck_info(did=DID)
#print at.deck_info(name=DECK_NAME)
#print len(at.card_info(did=DID))

#print at.cnt_cards(DID, DECK_NAME)


#deck = at.deck_info(name=DECK_NAME)
#deck_mid = deck['mid']
#print deck['id']

#note_w_mid = at.note_spec('id', mid=deck_mid)

#print note_w_mid

#print at.card_info(did=deck_id)