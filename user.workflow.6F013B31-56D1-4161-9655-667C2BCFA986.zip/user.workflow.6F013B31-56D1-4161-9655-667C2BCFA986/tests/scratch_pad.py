#!/usr/bin/env python
# -*- coding: utf-8 -*-

# [APPEND PATH]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)


# [IMPORT]
from anki import Collection as aopen

from atools import Tools


apath = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'
title = 'New test deck'
col = aopen(apath)
col.decks.id(title)
col.save()
col.close()
