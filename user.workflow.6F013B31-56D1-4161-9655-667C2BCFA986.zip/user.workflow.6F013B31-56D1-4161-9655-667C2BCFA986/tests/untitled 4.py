#!/usr/local/bin/python
# -*- coding: utf-8 -*-


# [Run from subdirectory]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)
#sys.path.append("/usr/share/anki")


# [IMPORT]
import re, glob
#import anki
from anki import storage, stats
from BeautifulSoup import BeautifulSoup, BeautifulStoneSoup, Tag, NavigableString



html = """<h1>Today</h1>Studied <b><!--studied-->1 card</b> in <b>8 seconds</b> today.<br />Again count: <b>1</b> (<b>0.0%</b> correct)<br />Learn: <b>1</b>, Review: <b>0</b>, Relearn: <b>0</b>, Filtered: <b>0</b><br />No mature cards were studied today."""

def strip_tags(html, invalid_tags):
    soup = BeautifulSoup(html)

    for tag in soup.findAll(True):
        if tag.name in invalid_tags:
            s = ""

            for c in tag.contents:
                if not isinstance(c, NavigableString):
                    c = strip_tags(unicode(c), invalid_tags)
                s += unicode(c)

            tag.replaceWith(s)

    return soup


invalid_tags = ['b']
print strip_tags(html, invalid_tags)