#!/usr/local/bin/python
# -*- coding: utf-8 -*-


# [Run from subdirectory]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)



# [IMPORT]
import re, glob
import sqlite3
import json

from anki import storage, stats
from BeautifulSoup import BeautifulSoup, Comment, NavigableString
from workflow import Workflow


DECK_NAME = 'Yousmle.com::Bacterial Viral Characteristics' #124


log = None
    
def get_col():
    default_locations = [
                         os.environ['HOME']+'/Anki/User 1/collection.anki2',
                         os.environ['HOME']+'/.anki/User 1/collection.anki2',
                         'collection.anki2'
                        ]
    for location in default_locations:
        if os.path.exists(location):
            return location
        else:
            home_path = os.path.expanduser('~')
            pattern = (home_path + '/**' + '/Anki' + '/*' + '/collection.anki2')
            for path in glob.glob(pattern):
                return path
    return None
        
    

class anki_db(object):

    def __init__(self, coll):

        self.conn = sqlite3.connect(coll)
        
    
    def db_decks(self):
        
        deck_db = self.conn.execute("SELECT decks FROM col")
        
        decks = json.loads(deck_db.fetchone()[0])
    
        for id, deck in decks.items():
            if deck['name'] == DECK_NAME:
                selected_deck = deck
                selected_deck['id'] = id
                break
        else:
            print("Unable to find the %r deck :(" % DECK_NAME)
            
        for deck in decks.items():
            print deck
            
        

        
    
#def db_handler(path, handler=None):
    

    
        


def main():
        

    apath = get_col()
#    coll = storage.Collection(apath)

#    handler = {
#            'deck_id': db_decks(),
#            }

    
    db = anki_db(apath)
    db.db_decks()
    
    
if __name__ == "__main__":
    main()