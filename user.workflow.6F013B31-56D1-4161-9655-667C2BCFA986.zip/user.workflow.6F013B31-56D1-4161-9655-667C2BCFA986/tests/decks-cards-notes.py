#!/usr/local/bin/python
# -*- coding: utf-8 -*-


# [Run from subdirectory]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)
#sys.path.append("/usr/share/anki")


# [IMPORT]
import re, glob
#import anki
import sqlite3
import json

from anki import storage, stats
from BeautifulSoup import BeautifulSoup, Comment, NavigableString



COLLECTION_PATH = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'

DECK_NAME = 'MEDICINE::Pharm - Drug of Addiction' #36
DID = '1427634157800'
NID = '1264521038872'
db = sqlite3.connect(COLLECTION_PATH)



def sync_info(db):
    import datetime    
    sync = db.execute("SELECT ls FROM col")
    
    sync_time = sync.fetchone()[0]
    
    print sync_time
#    print datetime.datetime.fromtimestamp(sync_time).strftime('%A, %b %d %I:%M:%S %p')



def deck_info_all(db):
    # name, extendRev, collapsed, browserCollapsed, newToday, timeToday, extendNew, conf, revToday, lrnToday, id, mod
    import datetime
    results = []
    
    decks = db.execute("SELECT decks FROM col")                     
    decks = json.loads(decks.fetchone()[0])

    for id, deck in decks.items():
        results.append(deck)
#        print datetime.datetime.fromtimestamp(deck['mod']).strftime('%A, %b %d %I:%M%p %Y')

    return results


def deck_info(db, **kwargs):
    import datetime
    
    options = {'did' : None, 'name' : None}
    options.update(kwargs)
    
    decks = db.execute("SELECT decks FROM col")
    decks = json.loads(decks.fetchone()[0])
    
    results = []
    
    for id, deck in decks.items():
        if options['did']:
            if id == options['did']:   
                return deck
        if options['name']:
            if deck['name'] == options['name']:
                results.append(deck)

    return results        

    
    '''
    selected_deck = deck
    return selected_deck
    selected_deck['id'] = id
    
    print deck['name']
    print deck['extendRev']
    print deck['collapsed']
#        print selected_deck['browserCollapsed']
    print deck['newToday']
    print deck['timeToday']
    print deck['extendNew']
    print deck['conf']
    print deck['revToday']
    print deck['lrnToday']
    print deck['id']
    mod_time = deck['mod']
    print datetime.datetime.fromtimestamp(mod_time).strftime('%A, %b %d %I:%M%p %Y')
    '''
        
        



def deck_config_all(db):

    
    configs = db.execute("SELECT dconf FROM col")    
    configs = json.loads(configs.fetchone()[0])
    
    for id, conf in configs.items():
        print conf['name']
        print conf['replayq']
        print conf['lapse']
        print conf['rev']
        print conf['timer']
        print conf['dyn']
        print conf['maxTaken']
        print conf['usn']
        print conf['new']
        print conf['mod']
        print conf['id']
        print conf['autoplay']



def model_info(db):

    
    models = db.execute("SELECT models FROM col")    
    models = json.loads(models.fetchone()[0])
    
    for id, model in models.items():
        print model['name']
        print model['tags']
        print model['did']
#        print model['usn']
#        print model['req']
#        print model['flds'] # {name:Front, media:[], sticky:bool, rtl:bool, ord:0, font, size}
#        print model['sortf'] 
#        print model['tmpls'] 
#        print model['mod']
#        print model['latexPost']
#        print model['type']
#        print model['id']
#        print model['css']
#        print model['latexPre']        





def card_info(db, **kwargs):
    # id, nid, did, ord, mod, usn, queue, due, ivl, factor, reps, lapses, left, odue, odid, flags, data
    
    options = {'nid' : None, 'did' : None, 'count' : False}
    options.update(kwargs)
    
    if options['did'] and options['count'] is True:
        
        cards_did = db.execute("SELECT COUNT(*) "
                                        "FROM cards "
                                        "WHERE cards.did = ?", (options['did'],) )
                    
        card_count = cards_did.fetchone()
        return card_count[0]
    
    elif options['nid']:

        rows = db.execute("SELECT * FROM cards WHERE cards.nid = ?", (options['nid'],))
        
        colname = [ d[0] for d in rows.description ]
        for r in rows.fetchall():
            card = dict((colname[i], r[i]) for i in range(len(colname)))
            return card
    
    elif options['did']:

        results = []
        
        rows = db.execute("SELECT cards.id, nid, did, ord, cards.mod, cards.usn, queue, due, ivl, factor, reps, lapses, left, odue, odid, cards.flags, cards.data "
                             "FROM cards "
                             "JOIN notes ON notes.id = cards.nid "
                             "WHERE cards.did = ?", (options['did'],) )
        

        colname = [ d[0] for d in rows.description ]        
        for r in rows:
            card = dict((colname[i], r[i]) for i in range(len(colname)))
            results.append(card)
       
        return results



def card_spec(db, v, **kwargs):
        

        sel = {'v':('card_' + v)}

        options = {'id' : None, 'nid' : None, 'did' : None}
        options.update(kwargs)
        
        if options['id']:
            key, value = 'id', options['id']
        elif options['nid']:
            key, value = 'nid', options['nid']
        elif options['did']:
            key, value = 'did', options['did']
        
        
        rows = db.execute("SELECT cards.id, cards.nid, cards.did, cards.ord, cards.mod, cards.usn, cards.queue, cards.due, cards.ivl, cards.factor, cards.reps, cards.lapses, cards.left, cards.odue, cards.odid, cards.flags, cards.data "
                             "FROM cards "
                             "JOIN notes ON notes.id = cards.nid "
                             "WHERE cards."+key+" = ?", (value,) )
   
        for card in rows:
            card_id, card_nid, card_did, card_ord, card_mod, card_usn, card_queue, card_due, card_ivl, card_factor, card_reps, card_lapses, card_left, card_odue, card_odid, card_flags, card_data = card
            return vars()[sel['v']]
    
    
    
    
def note_info(db, **kwargs):
    '''CALL note_info(db, nid='1232312', count=True)'''
    # id, guid, mod, usn, tags, flds, sfld, csum, flags, data
    

    options = {'nid' : None, 'count' : False}
    options.update(kwargs)
    

    if options['count'] is True:        
        notes = db.execute("SELECT count() FROM notes")
        total_notes = notes.fetchone()[0]
        return total_notes
        
                
    elif options['nid']:

        rows = db.execute("SELECT * FROM notes WHERE notes.id = ?", (options['nid'],))
        
        colname = [ d[0] for d in rows.description ]
        for r in rows.fetchall():
            return dict((colname[i], r[i]) for i in range(len(colname)))


#        for note in db.execute("SELECT id, guid, mod, usn, tags, flds, sfld, csum, flags, data "
#                                "FROM notes "
#                                "WHERE notes.id = ?", (options['nid'],)):

#            nid, guid, mod, usn, tags, flds, sfld, csum, flags, data = note
#            return note
   


#print card_info(db, nid='1419441282918')
#print card_spec(db, 'due', did='1419424106618')
#print card_spec(db, 'due', nid='1419441282918')
#note_info(db, count=True)
#note_info(db)


deck_name = deck_info(db, did=DID)['name']

all_deck_names = deck_info_all(db)


#print all_deck_names
deck_name = deck_name.split('::')[0]
#print deck_name


def match_deck(name, all_names):

    results = []
    
    key = ['name']
    
    for d in all_names:
        d1 = {k: d[k] for k in (key)}
        d2 = {k:v for k, v in d1.items() if name in str(v)}
        
        if len(d2.keys()):
            results.append(d2)

    return results
        #keys = new.keys()
        #values = new.values()
        #dict(zip(keys, values))
        #newer = {k:v for k,v in new['name'] if 'Yousmle' in v }
        #newest = {k:[elem for elem in v if 'Yousmle' in v] for k,v in new.iteritems()}
    
                    
matches = match_deck(deck_name, all_deck_names)


deck_ids = []
for match in matches:
    match = match['name']
    #print deck_info(db, name=match)[0]['mod']
    ids = deck_info(db, name=match)[0]['id']
    deck_ids.append(ids)
    
sum_cards = []
for ids in deck_ids:
    count = card_info(db, did=ids, count=True)
    sum_cards.append(count)
    
print sum(sum_cards)