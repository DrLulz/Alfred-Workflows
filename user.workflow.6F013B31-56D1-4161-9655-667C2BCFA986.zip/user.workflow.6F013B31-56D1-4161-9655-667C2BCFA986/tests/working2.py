# encoding: utf-8

## Structure from FuzzyFolders wf

import os, sys, re, subprocess
from lib.workflow import (Workflow, ICON_NOTE, ICON_WARNING,
                      ICON_INFO, ICON_SETTINGS, ICON_ERROR)
from lib.workflow.background import run_in_background, is_running

__version__ = '1.0'


# [] optional
# ()

__usage__ = """
anki.py <action> [<dir>] [<query>]

Usage:
    anki.py set <query>
    anki.py apath <apath>
    anki.py list <query>
    anki.py decks

Arguments:
    <query>     Search query
    <apath>     Directory path

Options:
    -h, --help      Show this help text

This script is meant to be called from Alfred.

"""

log = None
DELIMITER = '▸'
ICON = 'icon.png'

ALFRED_SCRIPT = 'tell application "Alfred 2" to search "{}"'

def _applescriptify(text):
    """Replace double quotes in text"""
    return text.replace('"', '" + quote + "')


def run_alfred(query):
    """Run Alfred with ``query`` via AppleScript"""
    script = ALFRED_SCRIPT.format(_applescriptify(query))
    log.debug('calling Alfred with : {!r}'.format(script))
    return subprocess.call(['osascript', '-e', script])


def get_col():
    import glob

    default_locations = [
                         os.environ['HOME']+'/Anki/User 1/collection.anki2',
                         os.environ['HOME']+'/.anki/User 1/collection.anki2',
                         'collection.anki2'
                        ]

    for location in default_locations:
        if os.path.exists(location):
            return location

    home_path = os.path.expanduser('~')
    pattern = (home_path + '/**' + '/Anki' + '/*' + '/collection.anki2')
    col_path = glob.glob(pattern)
    
    if col_path:
        return col_path[0]
    else:
        return None
        

def db_decks(apath):
    from atools import Tools
    
    at = Tools(apath)
    results =[]

    decks = at.all_decks()
    
    for d in decks:
        deck = {'id': None, 'title': None, 'cards': None, 'new': None, 'review': None}
        
        deck['id']    = str(d['id'])
        deck['title'] = d['name']
        deck['cards'] = str(at.cnt_cards(d['id'], d['name']))
        
        stats = at.deck_stats(deck['id'], deck['title'])
        n, r, l = stats['new'], stats['review'], stats['learning']
        deck['new'] = n
        deck['review'] = r+l
            
        results.append(deck)
        
    return results



class Anki_WF(object):

    def __init__(self, wf):
        self.wf = wf
        self.query = None
        self.apath = self.wf.settings.get('anki_path', None)
        
        
    def run(self, args):

        self.args = args

        # ------------------------------------------------------------------
        # Check if Anki collection path is set
         
        if not self.apath:
            self.apath = get_col()
            if self.apath is None:
                self.wf.add_item(
                    title    = "Run :aset",
                    subtitle = "Couldn't locate Anki's collection path.",
                    arg      = '',
                    valid    = False,
                    icon     = ICON_WARNING)
                self.wf.send_feedback()
                #run_alfred(':aset{} '.format(DELIMITER))
            elif self.apath:
                self.wf.settings['anki_path'] = self.apath
            return


        self.query = args['<query>']
        log.debug('query : {!r}'.format(self.query))

        actions = ('apath', 'set', 'list', 'decks')

        for action in actions:
            if args.get(action):
                methname = 'do_{}'.format(action.replace('-', '_'))
                meth = getattr(self, methname, None)
                if meth:
                    return meth()
                else:
                    break

        raise ValueError('Unknown action : {}'.format(action))


    ####################################################################
    # LIST DECKS
    ####################################################################

    def do_list(self):
        
        # Parse query
        # ------------------------------------------------------------------

        m = re.match(u'([^‣]+)(‣)?(.+)?', self.query)
        #m = re.match(u'([^‣]+)(‣)?([^‣]+)?(‣)?([^‣]+)?', self.query)

        if not m:
            self.wf.add_item('Create Deck?',
                        'or try a different query',
                        icon=ICON_WARNING)
            self.wf.send_feedback()
            return 0

        name, delim, query = m.groups()

        log.debug('name : {!r} delim : {!r}  query : {!r}'.format(
                  name, delim, query))
                  
                  
        if not delim:

            #def wrapper():
            #    return db_decks(self.apath)
            
            def key_for_deck(deck):
                return '{} {}'.format(deck['title'], deck['id'])

            decks = wf.cached_data('decks', None, max_age=0) #86400
            #decks = wf.cached_data('decks', wrapper, max_age=86400) #86400
            #log.debug(decks)
            
            if not wf.cached_data_fresh('decks', max_age=300):
                     cmd = ['/usr/bin/python', wf.workflowfile('background.py'), 'decks']
                     log.debug('CMD: {}'.format(cmd))
                     run_in_background('update', cmd)
                     
            if is_running('update'):
                     self.wf.add_item('Updating deck info',
                                 valid=False,
                                 icon=ICON)
            
            if self.query and decks:
                decks = wf.filter(name, decks, key_for_deck, min_score=20)
        
            if not decks:
                self.wf.add_item('No decks with that name. Create?', icon=ICON_WARNING)
                self.wf.send_feedback()
                #create_deck(apath, query)
                return 0
            
            # set uid
            for deck in decks:
                self.wf.add_item(
                    title    = deck['title'],
                    subtitle = 'Cards:{}   New:{}   Review:{}'.format(deck['cards'], deck['new'], deck['review']),
                    #arg      = '{} {}'.format(deck['id'], deck['title']),
                    autocomplete=wf.decode('{} ‣'.format(deck['title'])),
                    uid      = wf.decode(deck['id']),
                    #valid    = True,
                    icon     = 'icon.png')

            self.wf.send_feedback()
            return 0

        
        
        # ------------------------------------------------------------------
        # get did from selected deck name
        # pass did to {query}
        
        cmd = ['/usr/bin/python', self.wf.workflowfile('background.py'), 'did', name]
        log.debug('CMD DID: {}'.format(cmd))
        run_in_background('name2did', cmd)
        
        did = self.wf.cached_data('did', None, max_age=0)
        
        if did:
            self.wf.add_item(
                title    = 'New Card',
                subtitle = 'Create card in {}'.format(name),
                arg      = did,
                valid    = True,
                icon     = 'icon.png')

        
        self.wf.send_feedback()
        return 0
        
        
        
    ####################################################################
    # 
    ####################################################################

    def do_decks(self):
        return run_alfred('wuts ')
        self.wf.add_item('No Fuzzy Folder specified',
                         valid=False,
                         icon=ICON_ERROR)
        self.wf.send_feedback()
        return 0
        
        
    def do_apath(self):
        apath = self.args['<apath>']
        
        if not apath.endswith('collection.anki2'):
            self.wf.add_item(
                title    = "The path you entered isn't valid",
                subtitle = "Anki collections end with .anki2",
                valid    = False,
                icon     = ICON_WARNING)
            self.wf.send_feedback()
            return 0

        
        if not os.path.exists(apath):
            self.wf.add_item(
                title    = "Aww snap. The path doesn't exist.",
                subtitle = "The path entered doesn't exist.",
                valid    = False,
                icon     = ICON_WARNING)
            self.wf.send_feedback()
            return 0

        log.debug('apath: {}'.format(apath))
        self.wf.settings['anki_path'] = apath
        self.wf.send_feedback()
        
        
        
                

def main(wf):
    from docopt import docopt
    args = docopt(__usage__, argv=wf.args, version=__version__)
    
    log.debug('wf.args : {!r}'.format(wf.args))
    log.debug('args : {!r}'.format(args))
    
    awf = Anki_WF(wf)
    return awf.run(args)


if __name__ == '__main__':
    wf = Workflow(libraries=[os.path.join(os.path.dirname(__file__), 'lib')])
    log = wf.logger
    sys.exit(wf.run(main))