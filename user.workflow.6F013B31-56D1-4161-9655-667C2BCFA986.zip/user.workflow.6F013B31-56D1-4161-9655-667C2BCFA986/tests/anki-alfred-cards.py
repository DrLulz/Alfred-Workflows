#!/usr/local/bin/python
# -*- coding: utf-8 -*-

# [IMPORT]
import os, sys, re
import sqlite3, json
from workflow import Workflow
from atools import tools


log = None    

def db_cards(did, title):
    count = at.cnt_cards(did, title)
    return count
    

def main(wf):
    
    did = wf.cached_data('did', max_age=1)
    title = wf.cached_data('deck_title', max_age=1)
    try:
        title_abbr = title.split('::')[-1]
    except:
        title_abbr = title

    count = db_cards(did, title)

    wf.add_item(
        title=title_abbr,
        subtitle='Cards: '+str(count),
        arg=did,
        valid=True,
        icon='icon.png')

    wf.send_feedback()
    
    
    
if __name__ == '__main__':
    wf = Workflow()
    at = tools(wf.settings.get('anki_path', None))
    log = wf.logger
    sys.exit(wf.run(main))