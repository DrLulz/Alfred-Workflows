# encoding: utf-8

from lib.atools import Tools, AnkiFx
from anki import Collection as aopen
from anki import utils

import json, sqlite3




apath = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'
col = aopen(apath)
dm = col.decks

at = Tools(apath)
#db  = sqlite3.connect(apath)


#db.close()


#raise Exception('spam', 'eggs')




DID = '1428672590748'
NAME = 'MEDICINE::ACLS'

#print dm.cids(DID, children=True)

#print at.card_info(did=DID)

def cids(did):
    
    dids = [did]

    DECK = at.deck_info(did=did)
    NAME = DECK['name']
    
    kids = at._match_(NAME)


    kid_list = ()
    for k in kids:
        k, kid = k.values()
        kid_list = kid_list + ((k, kid),)
        
    for id, name in kid_list:
        dids.append(id)
        
    _list = list(at.dids2cids(utils.ids2str(dids)))
    return [i for sub in _list for i in sub]
    



print at.deck_notes(DID)
#print cids(DID)
#print map(list, cids(DID))
#print dm.cids(DID, children=True)