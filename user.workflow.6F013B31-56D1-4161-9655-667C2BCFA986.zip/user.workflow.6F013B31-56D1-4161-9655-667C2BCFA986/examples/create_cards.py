#!/usr/bin/env python
# -*- coding: utf-8 -*-

# [APPEND PATH]
import os, sys
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath) + '/main'
sys.path.append(dname)


# [IMPORT]
from anki import Collection as aopen
#from anki import models
from atools import Tools


apath = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'
col = aopen(apath)






def dark_theme(name, mm):
    
    path  = os.path.dirname(abspath) + '/template'
    f = path + '/front.txt'
    c = path + '/css.txt'
    b = path + '/back.txt'
    
    with open(f, 'r') as ft, open(c, 'r') as ct, open (b, 'r') as bt:
        ftemp = ft.read()
        css   = ct.read()
        btemp = bt.read()

    m  = mm.new(name)

    fld = mm.newField('Note ID'); mm.addField(m, fld)
    fld = mm.newField('Front');   mm.addField(m, fld)
    fld = mm.newField('F Note');  mm.addField(m, fld)
    fld = mm.newField('Back');    mm.addField(m, fld)
    fld = mm.newField('B Note');  mm.addField(m, fld)
    fld = mm.newField('class');   mm.addField(m, fld)
    fld = mm.newField('Noty');    mm.addField(m, fld)
    fld = mm.newField('http');    mm.addField(m, fld)
    fld = mm.newField('video');   mm.addField(m, fld)

    m['css'] = css

    t = mm.newTemplate('Card 1')
    t['qfmt'] = ftemp
    t['afmt'] = btemp
    mm.addTemplate(m, t)
    mm.add(m)
    return m
   

def get_model(mm, name):
    
    model = mm.byName(name)
    if model:
        return model
    else:
        return dark_theme(mm, name)
    
        

def create_card(did, data):
    
    mname = 'Alfred Dark'
    dm = col.decks
    mm = col.models

    deck = dm.get(did)
    dm.select(deck['id'])


    model = mm.byName(mname)
    if model is None:
        model = dark_theme(mname, mm)

    model['did'] = deck['id']
    mm.save(model)
    mm.setCurrent(model)

    card = col.newNote(forDeck=False)
    #for name in card.keys():

    card['Note ID'] = str(card.id)
    card['Front']   = data[0]
    card['F Note']  = ''
    card['Back']    = data[1]
    card['B Note']  = ''
    card['class']   = ''
    card['Noty']    = ''     
    card['http']    = '' 
    card['video']   = ''             
    col.addNote(card)
    col.save()
    col.close()

    

    
    



did = '1429732180832'
data = [u'Front', u'Back']
create_card(did, data)