import re
from anki import Collection as aopen
#from anki import cards, notes, utils
from anki import utils
from lib.atools import Tools

apath = '/Users/pguilford/Documents/Anki/DrLulz/collection.anki2'
at = Tools(apath)
col = aopen(apath)
dm = col.decks
mm = col.models


DID = '1419210638227'
#NAME = 'MEDICINE::ACLS::Pharmacology'
#NID = '1427038863829'
#MID = '1394808490619'
#print at.deck_info(name=NAME)



# ------------------------------------------------------------------
# get all card ids for did

cids = dm.cids(DID, children=True)



# ------------------------------------------------------------------
# collect all note ids for each card id

nids = []
for cid in cids:
    card = at.card_spec('nid', cid=cid)
    nids.append(card[0])


notes = []
for nid in nids:
    
    ndict = {'nid': None, 'flds': None, 'tags': None, 'mid': None, 'mname': None}

    # note info for each note id
    note = at.note_info(nid=nid)

    # readable note fields, strip HTML
    f = lambda x: [utils.stripHTMLMedia(i) for i in x]
    flds = f(filter(None, note['flds'].split('\x1f')))

    # from note model id, retrieve model fields
    mid = str(note['mid'])
    model = mm.get(mid)
    #model = at.model_info(mid=mid)
    
    # get field names for model
    mflds = [mfld['name'] for mfld in model['flds']]
    
    ndict['nid']   = nid
    ndict['flds']  = flds
    ndict['tags']  = note['tags']
    ndict['mid']   = mid
    ndict['mname'] = model['name']
    
    notes.append(ndict)

    '''
    # get the models template
    tmpls = model['tmpls']
    for tmpl in tmpls:
        k, v = tmpl.keys(), tmpl.values()
        
        # separate front & back templates
        ft_tmpl = tmpl['qfmt']
        bk_tmpl = tmpl['afmt']
        
        # get front/question fields from model, remove duplicates
        strip = re.subn(r'<(script).*?</\1>(?s)', '', ft_tmpl, 0)[0]
        m = re.findall(r'(?<={{)[^}]*', strip)
        front_mflds = list(set([i.replace('text:', '') for i in m]))

        # get back/answer fields from model, remove duplicates
        strip = re.subn(r'<(script).*?</\1>(?s)', '', bk_tmpl, 0)[0]
        m = re.findall(r'(?<={{)[^}]*', strip)
        back_mflds = list(set([i.replace('text:', '') for i in m]))
    '''


print notes


# return to alfred
# notes in deck
# note attributes: nid, flds, tags, mid, mname
